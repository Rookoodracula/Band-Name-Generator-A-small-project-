#1. Create a greeting for your program.
print("Welcome to the Band Name Generator")
#2. Ask the user for the city that they grew up in.
c = input("In which city did u grew in ?\n")
#3. Ask the user for the name of a pet.
p = input("whats ur pet's name ?\n")
#4. Combine the name of their city and pet and show them their band name.
print("ur band name could be\n" + c + " " + p )
#5. Make sure the input cursor shows on a new line:

# Solution: https://replit.com/@appbrewery/band-name-generator-end